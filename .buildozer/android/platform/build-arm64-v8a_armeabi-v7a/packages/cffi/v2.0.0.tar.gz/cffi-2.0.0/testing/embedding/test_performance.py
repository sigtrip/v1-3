import sys
from testing.embedding.test_basic import EmbeddingTests

if sys.platform == 'win32':
    import pytest
    pytestmark = pytest.mark.skip("written with POSIX functions")


class TestPerformance(EmbeddingTests):
    def test_perf_single_threaded(self):
        perf_cffi = self.prepare_module('perf')
        self.compile('perf-test', [perf_cffi], opt=True)
        output = self.execute('perf-test')
        print('='*79)
        print(output.rstrip())
        print('='*79)

    def test_perf_in_1_thread(self):
        perf_cffi = self.prepare_module('perf')
        self.compile('perf-test', [perf_cffi], opt=True, threads=True,
                     defines={'PTEST_USE_THREAD': '1'})
        output = self.execute('perf-test')
        print('='*79)
        print(output.rstrip())
        print('='*79)

    def test_perf_in_2_threads(self):
        perf_cffi = self.prepare_module('perf')
        self.compile('perf-test', [perf_cffi], opt=True, threads=True,
                     defines={'PTEST_USE_THREAD': '2'})
        output = self.execute('perf-test')
        print('='*79)
        print(output.rstrip())
        print('='*79)

    def test_perf_in_4_threads(self):
        perf_cffi = self.prepare_module('perf')
        self.compile('perf-test', [perf_cffi], opt=True, threads=True,
                     defines={'PTEST_USE_THREAD': '4'})
        output = self.execute('perf-test')
        print('='*79)
        print(output.rstrip())
        print('='*79)

    def test_perf_in_8_threads(self):
        perf_cffi = self.prepare_module('perf')
        self.compile('perf-test', [perf_cffi], opt=True, threads=True,
                     defines={'PTEST_USE_THREAD': '8'})
        output = self.execute('perf-test')
        print('='*79)
        print(output.rstrip())
        print('='*79)
